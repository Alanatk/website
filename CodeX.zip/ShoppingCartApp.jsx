import React, { useState } from "react";

function CartCount({ count }) {
  return (
    <div style={{ marginTop: "20px", fontSize: "20px", fontWeight: "bold" }}>
      Cart Count: {count}
    </div>
  );
}

export default function ShoppingCartApp() {
  const [cartItems, setCartItems] = useState([]);

  const products = [
    { id: 1, name: "Laptop" },
    { id: 2, name: "Phone" },
    { id: 3, name: "Headphones" },
    { id: 4, name: "Mouse" }
  ];

  const addToCart = (product) => {
    setCartItems([...cartItems, product]);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "40px", fontFamily: "Arial" }}>
      <h1>Shopping Cart System</h1>

      <h2>Products</h2>
      {products.map((product) => (
        <div key={product.id} style={{ margin: "10px" }}>
          <span style={{ marginRight: "15px" }}>{product.name}</span>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      ))}

      <CartCount count={cartItems.length} />
    </div>
  );
}