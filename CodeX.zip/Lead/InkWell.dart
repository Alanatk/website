import 'package:flutter/material.dart';

void main() {
  runApp(TapColorChangerApp());
}

class TapColorChangerApp extends StatelessWidget {
  const TapColorChangerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tap Color Changer App',
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Color boxColor = Colors.blue;
  String message = "Tap the box";

  void changeBox() {
    setState(() {
      if (boxColor == Colors.blue) {
        boxColor = Colors.green;
        message = "Color changed to Green";
      } else {
        boxColor = Colors.blue;
        message = "Color changed to Blue";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tap Color Changer App"),
        centerTitle: true,
      ),
      body: Center(
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: changeBox,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              height: 200,
              width: 200,
              decoration: BoxDecoration(
                color: boxColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}