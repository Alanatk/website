import 'package:flutter/material.dart';

void main() {
  runApp(const CustomProfileCardApp());
}

class CustomProfileCardApp extends StatelessWidget {
  const CustomProfileCardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Custom Profile Card App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ProfileCardPage(),
    );
  }
}

class ProfileCardPage extends StatelessWidget {
  const ProfileCardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Custom Profile Card"),
        centerTitle: true,
      ),
      backgroundColor: Colors.grey[200],
      body: const Center(
        child: CustomProfileCard(),
      ),
    );
  }
}

class CustomProfileCard extends StatelessWidget {
  const CustomProfileCard({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 320,
      height: 420,
      child: Stack(
        children: [
          ClipPath(
            clipper: CardClipper(),
            child: Container(
              width: 320,
              height: 420,
              color: Colors.blueAccent,
            ),
          ),
          CustomPaint(
            size: const Size(320, 420),
            painter: CardDecorationPainter(),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircleAvatar(
                  radius: 55,
                  backgroundImage: NetworkImage(
                    'https://i.pravatar.cc/300',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Alan Thomas",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Flutter Developer",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Passionate about building beautiful mobile apps with Flutter and creative UI design.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 25),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.blueAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: const Text("Follow"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CardClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 60);

    path.quadraticBezierTo(
      size.width * 0.25,
      size.height,
      size.width * 0.5,
      size.height - 40,
    );

    path.quadraticBezierTo(
      size.width * 0.75,
      size.height - 80,
      size.width,
      size.height - 20,
    );

    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}

class CardDecorationPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint circlePaint = Paint()
      ..color = Colors.white.withOpacity(0.15)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(
      Offset(size.width - 50, 60),
      45,
      circlePaint,
    );

    canvas.drawCircle(
      Offset(50, size.height - 80),
      35,
      circlePaint,
    );

    Paint linePaint = Paint()
      ..color = Colors.white.withOpacity(0.25)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    Path wavePath = Path();
    wavePath.moveTo(20, size.height * 0.25);
    wavePath.quadraticBezierTo(
      size.width * 0.4,
      size.height * 0.15,
      size.width * 0.8,
      size.height * 0.28,
    );

    canvas.drawPath(wavePath, linePaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}