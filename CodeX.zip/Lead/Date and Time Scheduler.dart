import 'package:flutter/material.dart';

void main() {
  runApp(const DateTimeSchedulerApp());
}

class DateTimeSchedulerApp extends StatelessWidget {
  const DateTimeSchedulerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Date Time Scheduler',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const SchedulerPage(),
    );
  }
}

class SchedulerPage extends StatefulWidget {
  const SchedulerPage({super.key});

  @override
  State<SchedulerPage> createState() => _SchedulerPageState();
}

class _SchedulerPageState extends State<SchedulerPage> {
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  Future<void> pickDate() async {
    DateTime now = DateTime.now();

    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (pickedDate != null) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }

  Future<void> pickTime() async {
    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (pickedTime != null) {
      setState(() {
        selectedTime = pickedTime;
      });
    }
  }

  String getDateText() {
    if (selectedDate == null) {
      return 'No date selected';
    }
    return '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}';
  }

  String getTimeText() {
    if (selectedTime == null) {
      return 'No time selected';
    }
    return selectedTime!.format(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scheduler App'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.schedule,
                size: 80,
                color: Colors.blue,
              ),
              const SizedBox(height: 20),

              Text(
                'Selected Date: ${getDateText()}',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),

              Text(
                'Selected Time: ${getTimeText()}',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 30),

              ElevatedButton(
                onPressed: pickDate,
                child: const Text('Pick Date'),
              ),
              const SizedBox(height: 15),

              ElevatedButton(
                onPressed: pickTime,
                child: const Text('Pick Time'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}