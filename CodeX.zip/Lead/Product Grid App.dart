import 'package:flutter/material.dart';

void main() {
  runApp(ProductGridApp());
}

class ProductGridApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Product Grid App',
      home: ProductGridScreen(),
    );
  }
}

class ProductGridScreen extends StatelessWidget {
  final List<Map<String, dynamic>> products = [
    {"name": "Laptop", "icon": Icons.laptop, "color": Colors.blue},
    {"name": "Phone", "icon": Icons.phone_android, "color": Colors.green},
    {"name": "Watch", "icon": Icons.watch, "color": Colors.orange},
    {"name": "Camera", "icon": Icons.camera_alt, "color": Colors.purple},
    {"name": "Headset", "icon": Icons.headphones, "color": Colors.red},
    {"name": "Keyboard", "icon": Icons.keyboard, "color": Colors.teal},
    {"name": "Mouse", "icon": Icons.mouse, "color": Colors.brown},
    {"name": "Tablet", "icon": Icons.tablet_mac, "color": Colors.indigo},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product Grid App"),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: GridView.builder(
          itemCount: products.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.9,
          ),
          itemBuilder: (context, index) {
            return Container(
              decoration: BoxDecoration(
                color: products[index]["color"].withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: products[index]["color"],
                  width: 2,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    products[index]["icon"],
                    size: 50,
                    color: products[index]["color"],
                  ),
                  SizedBox(height: 15),
                  Text(
                    products[index]["name"],
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: products[index]["color"],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}



//Custom ListView App
// import 'package:flutter/material.dart';

// void main() {
//   runApp(CustomListViewApp());
// }

// class CustomListViewApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Custom ListView App',
//       home: ListScreen(),
//     );
//   }
// }

// class ListScreen extends StatelessWidget {
//   final List<Map<String, dynamic>> items = [
//     {"title": "Apple", "subtitle": "Fresh red apple", "icon": Icons.apple},
//     {"title": "Book", "subtitle": "Interesting story book", "icon": Icons.book},
//     {"title": "Phone", "subtitle": "Smart mobile device", "icon": Icons.phone_android},
//     {"title": "Bike", "subtitle": "Fast sports bike", "icon": Icons.pedal_bike},
//     {"title": "Camera", "subtitle": "Capture moments", "icon": Icons.camera_alt},
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Custom ListView App"),
//         centerTitle: true,
//         backgroundColor: Colors.blue,
//       ),
//       body: ListView.builder(
//         itemCount: items.length,
//         itemBuilder: (context, index) {
//           return Card(
//             margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//             elevation: 5,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(15),
//             ),
//             child: ListTile(
//               leading: CircleAvatar(
//                 radius: 28,
//                 backgroundColor: Colors.blue.shade100,
//                 child: Icon(
//                   items[index]["icon"],
//                   color: Colors.blue,
//                   size: 28,
//                 ),
//               ),
//               title: Text(
//                 items[index]["title"],
//                 style: TextStyle(fontWeight: FontWeight.bold),
//               ),
//               subtitle: Text(items[index]["subtitle"]),
//               trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }