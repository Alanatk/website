import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Custom Profile Card',
      home: const ProfileCardScreen(),
    );
  }
}

class ProfileCardScreen extends StatelessWidget {
  const ProfileCardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Custom Profile Card"),
        centerTitle: true,
      ),
      body: Center(
        child: CustomPaint(
          painter: CardShadowPainter(),
          child: ClipPath(
            clipper: CardClipper(),
            child: Container(
              width: 300,
              height: 200,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue, Colors.purple],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(
                      "https://i.pravatar.cc/150?img=3",
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Alan Thomas",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "Flutter Developer",
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CardClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 40);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 40);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class CardShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path shadowPath = Path();
    shadowPath.lineTo(0, size.height - 40);
    shadowPath.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 40);
    shadowPath.lineTo(size.width, 0);
    shadowPath.close();

    canvas.drawShadow(shadowPath, Colors.black, 6, true);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}