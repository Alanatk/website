import 'package:flutter/material.dart';

void main() {
  runApp(const WidgetStateDemoApp());
}

class WidgetStateDemoApp extends StatelessWidget {
  const WidgetStateDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Widget State Demo',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stateless vs Stateful'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: const [
            StaticProfileCard(),
            SizedBox(height: 20),
            InteractiveLikeCard(),
          ],
        ),
      ),
    );
  }
}

// -------------------- Stateless Widget Example --------------------
class StaticProfileCard extends StatelessWidget {
  const StaticProfileCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(15),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        children: const [
          CircleAvatar(
            radius: 35,
            backgroundColor: Colors.blue,
            child: Icon(Icons.person, size: 40, color: Colors.white),
          ),
          SizedBox(height: 10),
          Text(
            'Stateless Widget',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 5),
          Text(
            'This card shows fixed information.\nIt does not change during runtime.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}

// -------------------- Stateful Widget Example --------------------
class InteractiveLikeCard extends StatefulWidget {
  const InteractiveLikeCard({super.key});

  @override
  State<InteractiveLikeCard> createState() => _InteractiveLikeCardState();
}

class _InteractiveLikeCardState extends State<InteractiveLikeCard> {
  int likeCount = 0;
  bool isLiked = false;

  void toggleLike() {
    setState(() {
      if (isLiked) {
        likeCount--;
        isLiked = false;
      } else {
        likeCount++;
        isLiked = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.pink.shade100,
        borderRadius: BorderRadius.circular(15),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          const CircleAvatar(
            radius: 35,
            backgroundColor: Colors.pink,
            child: Icon(Icons.favorite, size: 40, color: Colors.white),
          ),
          const SizedBox(height: 10),
          const Text(
            'Stateful Widget',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 5),
          Text(
            'Likes: $likeCount',
            style: const TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: toggleLike,
            icon: Icon(isLiked ? Icons.favorite : Icons.favorite_border),
            label: Text(isLiked ? 'Unlike' : 'Like'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.pink,
              foregroundColor: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'This widget changes its UI when the button is pressed.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}