import 'package:flutter/material.dart';

void main() {
  runApp(StyledListViewApp());
}

class StyledListViewApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: StyledListViewPage(),
    );
  }
}

class StyledListViewPage extends StatelessWidget {
  final List<Map<String, dynamic>> items = [
    {"title": "Apple", "color": Colors.red.shade100},
    {"title": "Banana", "color": Colors.yellow.shade100},
    {"title": "Orange", "color": Colors.orange.shade100},
    {"title": "Grapes", "color": Colors.purple.shade100},
    {"title": "Mango", "color": Colors.green.shade100},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Custom Styled ListView"),
        backgroundColor: Colors.teal,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Container(
            margin: EdgeInsets.symmetric(vertical: 8),
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: items[index]["color"],
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade400,
                  blurRadius: 4,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Text(
              items[index]["title"],
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
                fontStyle: FontStyle.italic,
              ),
            ),
          );
        },
      ),
    );
  }
}