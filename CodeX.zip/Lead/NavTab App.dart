import 'package:flutter/material.dart';

void main() {
  runApp(const NavTabApp());
}

class NavTabApp extends StatelessWidget {
  const NavTabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NavTab App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    TabScreen(title: "Home Tabs"),
    TabScreen(title: "Profile Tabs"),
    TabScreen(title: "Settings Tabs"),
  ];

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: onItemTapped,
        selectedItemColor: Colors.blue,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: "Settings",
          ),
        ],
      ),
    );
  }
}

class TabScreen extends StatelessWidget {
  final String title;
  const TabScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.info), text: "Tab 1"),
              Tab(icon: Icon(Icons.star), text: "Tab 2"),
              Tab(icon: Icon(Icons.favorite), text: "Tab 3"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(
              child: Text(
                "Content of Tab 1",
                style: TextStyle(fontSize: 22),
              ),
            ),
            Center(
              child: Text(
                "Content of Tab 2",
                style: TextStyle(fontSize: 22),
              ),
            ),
            Center(
              child: Text(
                "Content of Tab 3",
                style: TextStyle(fontSize: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }
}