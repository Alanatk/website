import 'package:flutter/material.dart';

void main() {
  runApp(const SliderFeatureApp());
}

class SliderFeatureApp extends StatelessWidget {
  const SliderFeatureApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Slider Feature App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const FontSizeSliderScreen(),
    );
  }
}

class FontSizeSliderScreen extends StatefulWidget {
  const FontSizeSliderScreen({super.key});

  @override
  State<FontSizeSliderScreen> createState() => _FontSizeSliderScreenState();
}

class _FontSizeSliderScreenState extends State<FontSizeSliderScreen> {
  double fontSize = 20;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Slider Feature App"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Adjust My Font Size",
              style: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 40),
            Text(
              "Font Size: ${fontSize.toStringAsFixed(0)}",
              style: const TextStyle(fontSize: 18),
            ),
            Slider(
              value: fontSize,
              min: 10,
              max: 50,
              divisions: 8,
              label: fontSize.toStringAsFixed(0),
              onChanged: (value) {
                setState(() {
                  fontSize = value;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}