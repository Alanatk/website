import React, { createContext, useContext, useState } from "react";

const ThemeContext = createContext();

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

function Navbar() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <nav
      style={{
        background: theme === "dark" ? "#333" : "#eee",
        color: theme === "dark" ? "#fff" : "#000",
        padding: "10px",
      }}
    >
      <strong>My App</strong>
      <button onClick={toggleTheme} style={{ marginLeft: "20px" }}>
        Switch to {theme === "light" ? "Dark" : "Light"} Mode
      </button>
    </nav>
  );
}

function MainContent() {
  const { theme } = useContext(ThemeContext);

  return (
    <div
      style={{
        background: theme === "dark" ? "#222" : "#fff",
        color: theme === "dark" ? "#f0f0f0" : "#000",
        padding: "20px",
        minHeight: "200px",
      }}
    >
      <h2>Main Content</h2>
      <p>Current theme: <strong>{theme}</strong></p>
      <p>This component reads the theme using useContext.</p>
    </div>
  );
}

function Footer() {
  const { theme } = useContext(ThemeContext);

  return (
    <footer
      style={{
        background: theme === "dark" ? "#333" : "#eee",
        color: theme === "dark" ? "#aaa" : "#555",
        padding: "10px",
        textAlign: "center",
      }}
    >
      Footer - Theme: {theme}
    </footer>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Navbar />
      <MainContent />
      <Footer />
    </ThemeProvider>
  );
}
