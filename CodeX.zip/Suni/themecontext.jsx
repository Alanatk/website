import React, { createContext, useContext, useState } from "react";

const ThemeContext = createContext();

function useTheme() {
  return useContext(ThemeContext);
}

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  const styles = {
    background: theme === "light" ? "#ffffff" : "#1a1a1a",
    color: theme === "light" ? "#000000" : "#ffffff",
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, styles }}>
      {children}
    </ThemeContext.Provider>
  );
}

function Header() {
  const { theme, toggleTheme, styles } = useTheme();

  return (
    <header style={{ ...styles, padding: "15px", borderBottom: "1px solid #ccc" }}>
      <h2 style={{ margin: 0 }}>My Website</h2>
      <button onClick={toggleTheme}>
        Switch to {theme === "light" ? "🌙 Dark" : "☀️ Light"} Mode
      </button>
    </header>
  );
}

function Sidebar() {
  const { theme, styles } = useTheme();

  return (
    <aside
      style={{
        ...styles,
        width: "200px",
        padding: "15px",
        border: "1px solid #ccc",
      }}
    >
      <h3>Sidebar</h3>
      <p>Theme: {theme}</p>
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
    </aside>
  );
}

function Content() {
  const { styles } = useTheme();

  return (
    <main style={{ ...styles, flex: 1, padding: "15px" }}>
      <h3>Main Content</h3>
      <p>This component uses useContext to read the current theme.</p>
      <p>All components update simultaneously when the theme is toggled.</p>
    </main>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Header />
      <div style={{ display: "flex" }}>
        <Sidebar />
        <Content />
      </div>
    </ThemeProvider>
  );
}
