import React, { useState } from "react";

const products = [
  { id: 1, name: "Apple", price: 1.5 },
  { id: 2, name: "Banana", price: 0.75 },
  { id: 3, name: "Cherry", price: 3.0 },
  { id: 4, name: "Mango", price: 2.0 },
];

function CartSummary({ cartItems }) {
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ border: "1px solid blue", padding: "10px" }}>
      <h3>Cart Summary (Child Component)</h3>
      <p>Total Items: <strong>{cartItems.length}</strong></p>
      {cartItems.length === 0 ? (
        <p>Cart is empty.</p>
      ) : (
        cartItems.map((item, index) => (
          <div key={index}>
            {item.name} - ₹{item.price}
          </div>
        ))
      )}
      <p>Total: ₹{total.toFixed(2)}</p>
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div>
      <h2>Shopping Cart</h2>

      {/* Product List */}
      <div>
        <h3>Products (Parent Component)</h3>
        {products.map((p) => (
          <div key={p.id}>
            {p.name} - ₹{p.price}
            <button onClick={() => addToCart(p)}>Add to Cart</button>
          </div>
        ))}
      </div>

      {/* Child Component receives cartItems */}
      <CartSummary cartItems={cart} />
    </div>
  );
}
