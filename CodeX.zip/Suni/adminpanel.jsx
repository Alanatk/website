import React, { createContext, useContext, useState } from "react";
import { BrowserRouter, Routes, Route, Link, Navigate, useNavigate } from "react-router-dom";

const AuthContext = createContext();

function AuthProvider({ children }) {
  const [user, setUser] = useState(null); 

  const login = (username, password) => {
    
    const users = {
      admin: { username: "admin", password: "admin123", role: "admin" },
      user: { username: "user", password: "user123", role: "user" },
    };

    const found = users[username];
    if (found && found.password === password) {
      setUser(found);
      return true;
    }
    return false;
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}


function AdminRoute({ children }) {
  const { user } = useContext(AuthContext);

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (user.role !== "admin") {
    return <Navigate to="/home" />;  
  }

  return children;
}


function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = () => {
    const success = login(username, password);
    if (success) {
      navigate("/home");
    } else {
      setError("Invalid username or password.");
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <p style={{ color: "#888" }}>Try: admin / admin123 or user / user123</p>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <br /><br />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <br /><br />
      <button onClick={handleLogin}>Login</button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}


function HomePage() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div>
      <h2>Home Page</h2>
      <p>Welcome, <strong>{user?.username}</strong>! Role: {user?.role}</p>
      <nav>
        <Link to="/home">Home</Link> |{" "}
        {user?.role === "admin" && <Link to="/admin"> Admin Panel</Link>}
        {" | "}
        <button onClick={handleLogout}>Logout</button>
      </nav>
      <p>You are logged in as a <strong>{user?.role}</strong>.</p>
      {user?.role !== "admin" && (
        <p style={{ color: "red" }}>
          You do not have access to the Admin Panel.
        </p>
      )}
    </div>
  );
}


function AdminPanel() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div>
      <h2>Admin Panel</h2>
      <p>Welcome, Admin <strong>{user?.username}</strong>!</p>
      <nav>
        <Link to="/home">Home</Link> |{" "}
        <button onClick={handleLogout}>Logout</button>
      </nav>

      <div style={{ border: "1px solid green", padding: "20px", marginTop: "10px" }}>
        <h3>Admin Dashboard</h3>
        <p>Total Users: 128</p>
        <p>Active Users: 94</p>
        <p>Reports: 12 pending</p>
        <p style={{ color: "green" }}>
          This page is only visible to admin users.
        </p>
      </div>
    </div>
  );
}

// Main App
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/home" element={<HomePage />} />
          <Route
            path="/admin"
            element={
              <AdminRoute>
                <AdminPanel />
              </AdminRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
