import React, { useReducer, useState } from "react";

const initialState = {
  todos: [],
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD":
      return {
        todos: [
          ...state.todos,
          { id: Date.now(), text: action.text, done: false },
        ],
      };

    case "TOGGLE":
      return {
        todos: state.todos.map((todo) =>
          todo.id === action.id ? { ...todo, done: !todo.done } : todo
        ),
      };

    case "REMOVE":
      return {
        todos: state.todos.filter((todo) => todo.id !== action.id),
      };

    default:
      return state;
  }
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [input, setInput] = useState("");

  const handleAdd = () => {
    if (input.trim()) {
      dispatch({ type: "ADD", text: input.trim() });
      setInput("");
    }
  };

  const pending = state.todos.filter((t) => !t.done).length;
  const completed = state.todos.filter((t) => t.done).length;

  return (
    <div>
      <h2>Todo List (useReducer)</h2>

      {/* Add Task */}
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Add a new task..."
      />
      <button onClick={handleAdd}>Add</button>

      {/* Stats */}
      <p>
        Total: {state.todos.length} | Pending: {pending} | Completed: {completed}
      </p>

      {/* Todo List */}
      {state.todos.length === 0 ? (
        <p>No tasks yet. Add one above!</p>
      ) : (
        state.todos.map((todo) => (
          <div key={todo.id} style={{ margin: "8px 0" }}>
            <input
              type="checkbox"
              checked={todo.done}
              onChange={() => dispatch({ type: "TOGGLE", id: todo.id })}
            />
            <span
              style={{
                marginLeft: "8px",
                textDecoration: todo.done ? "line-through" : "none",
                color: todo.done ? "#aaa" : "#000",
              }}
            >
              {todo.text}
            </span>
            <button
              onClick={() => dispatch({ type: "REMOVE", id: todo.id })}
              style={{ marginLeft: "10px" }}
            >
              Remove
            </button>
          </div>
        ))
      )}
    </div>
  );
}
