import React from 'react'
import Admin from './AdminPanel'
import App from './AutoSave'


const App = () => {
  return (
    <div>
      <AutoSave/>
    </div>
  )
}

export default App