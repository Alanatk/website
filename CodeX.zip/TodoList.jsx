import React, { useReducer, useState } from "react";

const initialState = {
  tasks: []
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TASK":
      if (action.payload.trim() === "") return state;
      return {
        ...state,
        tasks: [
          ...state.tasks,
          {
            id: Date.now(),
            text: action.payload,
            completed: false
          }
        ]
      };

    case "TOGGLE_TASK":
      return {
        ...state,
        tasks: state.tasks.map((task) =>
          task.id === action.payload
            ? { ...task, completed: !task.completed }
            : task
        )
      };

    case "REMOVE_TASK":
      return {
        ...state,
        tasks: state.tasks.filter((task) => task.id !== action.payload)
      };

    default:
      return state;
  }
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [taskInput, setTaskInput] = useState("");

  const addTask = () => {
    dispatch({ type: "ADD_TASK", payload: taskInput });
    setTaskInput("");
  };

  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h1>Todo List Manager</h1>

      <input
        type="text"
        placeholder="Enter a task"
        value={taskInput}
        onChange={(e) => setTaskInput(e.target.value)}
        style={{ padding: "8px", width: "200px" }}
      />
      <button onClick={addTask} style={{ marginLeft: "10px", padding: "8px" }}>
        Add
      </button>

      <ul style={{ listStyle: "none", padding: 0, marginTop: "20px" }}>
        {state.tasks.map((task) => (
          <li key={task.id} style={{ margin: "10px 0" }}>
            <span
              onClick={() => dispatch({ type: "TOGGLE_TASK", payload: task.id })}
              style={{
                cursor: "pointer",
                textDecoration: task.completed ? "line-through" : "none",
                marginRight: "10px"
              }}
            >
              {task.text}
            </span>
            <button
              onClick={() => dispatch({ type: "REMOVE_TASK", payload: task.id })}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}