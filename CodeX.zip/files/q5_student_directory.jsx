// Q5 - Student Directory with Simulated Data Fetching
import React, { useState, useEffect } from "react";

// Simulated student data
const studentData = [
  { id: 1, name: "Asha Kumar", age: 20, branch: "Computer Science", email: "asha@college.com" },
  { id: 2, name: "Rohan Nair", age: 21, branch: "Electronics", email: "rohan@college.com" },
  { id: 3, name: "Priya Menon", age: 19, branch: "Mechanical", email: "priya@college.com" },
  { id: 4, name: "Arjun Das", age: 22, branch: "Civil", email: "arjun@college.com" },
];

// Student Profile Component
function StudentProfile({ student, onBack }) {
  return (
    <div>
      <button onClick={onBack}>← Back to Directory</button>
      <h3>Student Profile</h3>
      <p><strong>Name:</strong> {student.name}</p>
      <p><strong>Age:</strong> {student.age}</p>
      <p><strong>Branch:</strong> {student.branch}</p>
      <p><strong>Email:</strong> {student.email}</p>
      <p><strong>Student ID:</strong> STU00{student.id}</p>
    </div>
  );
}

// Student List Component
function StudentList({ students, onSelect }) {
  return (
    <div>
      <h3>All Students</h3>
      {students.map((s) => (
        <div
          key={s.id}
          style={{ border: "1px solid #ccc", padding: "10px", margin: "8px 0", cursor: "pointer" }}
          onClick={() => onSelect(s)}
        >
          <strong>{s.name}</strong> — {s.branch}
          <span style={{ marginLeft: "10px", color: "blue" }}>View Profile →</span>
        </div>
      ))}
    </div>
  );
}

// Main App
export default function App() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStudent, setSelectedStudent] = useState(null);

  // Simulate data fetching with delay
  useEffect(() => {
    setTimeout(() => {
      setStudents(studentData);
      setLoading(false);
    }, 1500); // 1.5 second simulated delay
  }, []);

  if (loading) {
    return <p>Loading students...</p>;
  }

  if (selectedStudent) {
    return (
      <StudentProfile
        student={selectedStudent}
        onBack={() => setSelectedStudent(null)}
      />
    );
  }

  return (
    <div>
      <h2>Student Directory</h2>
      <StudentList students={students} onSelect={setSelectedStudent} />
    </div>
  );
}
