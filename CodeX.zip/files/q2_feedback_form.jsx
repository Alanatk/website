// Q2 - Feedback Form: Submit and Display All Responses
import React, { useState } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [feedback, setFeedback] = useState("");
  const [responses, setResponses] = useState([]);
  const [message, setMessage] = useState("");

  const handleSubmit = () => {
    if (!name.trim() || !feedback.trim()) {
      setMessage("Please fill in all fields.");
      return;
    }

    const newResponse = {
      id: Date.now(),
      name: name.trim(),
      feedback: feedback.trim(),
      time: new Date().toLocaleTimeString(),
    };

    setResponses([newResponse, ...responses]);
    setName("");
    setFeedback("");
    setMessage("Feedback submitted successfully!");

    setTimeout(() => setMessage(""), 3000);
  };

  return (
    <div>
      <h2>Feedback Form</h2>

      {/* Submission Form */}
      <div>
        <input
          type="text"
          placeholder="Your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <textarea
          placeholder="Your feedback..."
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          rows={4}
        />
        <br />
        <button onClick={handleSubmit}>Submit Feedback</button>
        {message && <p>{message}</p>}
      </div>

      {/* Display All Responses */}
      <h3>All Responses ({responses.length})</h3>
      {responses.length === 0 ? (
        <p>No feedback yet.</p>
      ) : (
        responses.map((r) => (
          <div
            key={r.id}
            style={{ border: "1px solid #ccc", padding: "10px", margin: "8px 0" }}
          >
            <strong>{r.name}</strong> <small>({r.time})</small>
            <p>{r.feedback}</p>
          </div>
        ))
      )}
    </div>
  );
}
