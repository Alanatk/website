// Q7 - Weather App with Simulated Data Fetch
import React, { useState } from "react";

// Simulated weather database
const weatherData = {
  delhi: { city: "Delhi", temp: 34, description: "Sunny", humidity: 40, wind: 12 },
  mumbai: { city: "Mumbai", temp: 28, description: "Partly Cloudy", humidity: 75, wind: 18 },
  kochi: { city: "Kochi", temp: 30, description: "Humid and Cloudy", humidity: 85, wind: 10 },
  bangalore: { city: "Bangalore", temp: 24, description: "Pleasant", humidity: 60, wind: 8 },
  chennai: { city: "Chennai", temp: 32, description: "Hot", humidity: 70, wind: 15 },
};

export default function App() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchWeather = () => {
    if (!city.trim()) {
      setError("Please enter a city name.");
      return;
    }

    setLoading(true);
    setWeather(null);
    setError("");

    // Simulate API delay
    setTimeout(() => {
      const data = weatherData[city.trim().toLowerCase()];
      if (data) {
        setWeather(data);
      } else {
        setError("City not found. Try: Delhi, Mumbai, Kochi, Bangalore, Chennai");
      }
      setLoading(false);
    }, 1500);
  };

  return (
    <div>
      <h2>Weather App</h2>

      <input
        type="text"
        placeholder="Enter city name..."
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={fetchWeather}>Search</button>

      {loading && <p>Fetching weather data...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {weather && (
        <div style={{ border: "1px solid #ccc", padding: "20px", marginTop: "10px" }}>
          <h3>{weather.city}</h3>
          <p style={{ fontSize: "32px" }}>{weather.temp}°C</p>
          <p>{weather.description}</p>
          <p>Humidity: {weather.humidity}%</p>
          <p>Wind Speed: {weather.wind} km/h</p>
        </div>
      )}
    </div>
  );
}
