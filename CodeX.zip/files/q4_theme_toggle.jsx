// Q4 - Global Theme Toggle (Light / Dark Mode) using Context API
import React, { createContext, useContext, useState } from "react";

// 1. Create Theme Context
const ThemeContext = createContext();

// 2. Theme Provider
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// 3. Navbar Component (uses theme from context)
function Navbar() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <nav
      style={{
        background: theme === "dark" ? "#333" : "#eee",
        color: theme === "dark" ? "#fff" : "#000",
        padding: "10px",
      }}
    >
      <strong>My App</strong>
      <button onClick={toggleTheme} style={{ marginLeft: "20px" }}>
        Switch to {theme === "light" ? "Dark" : "Light"} Mode
      </button>
    </nav>
  );
}

// 4. Main Content Component (uses theme from context)
function MainContent() {
  const { theme } = useContext(ThemeContext);

  return (
    <div
      style={{
        background: theme === "dark" ? "#222" : "#fff",
        color: theme === "dark" ? "#f0f0f0" : "#000",
        padding: "20px",
        minHeight: "200px",
      }}
    >
      <h2>Main Content</h2>
      <p>Current theme: <strong>{theme}</strong></p>
      <p>This component reads the theme using useContext.</p>
    </div>
  );
}

// 5. Footer Component (uses theme from context)
function Footer() {
  const { theme } = useContext(ThemeContext);

  return (
    <footer
      style={{
        background: theme === "dark" ? "#333" : "#eee",
        color: theme === "dark" ? "#aaa" : "#555",
        padding: "10px",
        textAlign: "center",
      }}
    >
      Footer - Theme: {theme}
    </footer>
  );
}

// 6. App wraps everything in ThemeProvider
export default function App() {
  return (
    <ThemeProvider>
      <Navbar />
      <MainContent />
      <Footer />
    </ThemeProvider>
  );
}
