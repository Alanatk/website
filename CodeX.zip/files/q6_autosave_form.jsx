// Q6 - Exam Feedback Form with Auto-Save using localStorage
import React, { useState, useEffect } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [answer, setAnswer] = useState("");
  const [saveStatus, setSaveStatus] = useState("");

  // Load saved data on first render
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("examFormData") || "{}");
    if (saved.name) setName(saved.name);
    if (saved.answer) setAnswer(saved.answer);
    if (saved.name || saved.answer) {
      setSaveStatus("Restored from last save.");
    }
  }, []);

  // Auto-save every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const data = { name, answer };
      localStorage.setItem("examFormData", JSON.stringify(data));
      setSaveStatus("Auto-saved at " + new Date().toLocaleTimeString());
    }, 5000);

    return () => clearInterval(interval); // Cleanup on unmount
  }, [name, answer]);

  const handleClear = () => {
    setName("");
    setAnswer("");
    localStorage.removeItem("examFormData");
    setSaveStatus("Form cleared.");
  };

  const handleSubmit = () => {
    alert(`Submitted!\nName: ${name}\nAnswer: ${answer}`);
    localStorage.removeItem("examFormData");
  };

  return (
    <div>
      <h2>Exam Feedback Form</h2>
      <p style={{ color: "green" }}>{saveStatus}</p>

      <div>
        <label>Student Name:</label>
        <br />
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
        />
      </div>

      <br />

      <div>
        <label>Your Answer:</label>
        <br />
        <textarea
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          rows={6}
          cols={50}
          placeholder="Write your answer here..."
        />
      </div>

      <br />
      <button onClick={handleSubmit}>Submit</button>
      <button onClick={handleClear} style={{ marginLeft: "10px" }}>
        Clear
      </button>

      <p style={{ color: "#888", fontSize: "12px" }}>
        * Form auto-saves every 5 seconds to prevent data loss.
      </p>
    </div>
  );
}
