// Q10 - Blog Site with React Router Navigation
// Install: npm install react-router-dom
import React from "react";
import { BrowserRouter, Routes, Route, Link, useParams } from "react-router-dom";

// Blog post data
const posts = [
  {
    id: 1,
    title: "Getting Started with React",
    date: "March 10, 2025",
    content:
      "React is a JavaScript library for building user interfaces. It uses a component-based architecture that makes code reusable and maintainable. Components can be functional or class-based. React uses JSX syntax which looks like HTML inside JavaScript.",
  },
  {
    id: 2,
    title: "Understanding useState Hook",
    date: "March 12, 2025",
    content:
      "useState is a React Hook that lets you add state to functional components. It returns an array with two elements: the current state value and a setter function. Calling the setter function with a new value triggers a re-render of the component.",
  },
  {
    id: 3,
    title: "useEffect Explained",
    date: "March 14, 2025",
    content:
      "useEffect lets you perform side effects in functional components. Examples of side effects include data fetching, subscriptions, or manually changing the DOM. It runs after every render by default. The dependency array controls when it re-runs.",
  },
];

// Home Page - List of all posts
function Home() {
  return (
    <div>
      <h2>My Blog</h2>
      {posts.map((post) => (
        <div key={post.id} style={{ border: "1px solid #ccc", padding: "10px", margin: "10px 0" }}>
          <h3>{post.title}</h3>
          <p>{post.date}</p>
          <Link to={`/post/${post.id}`}>Read More →</Link>
        </div>
      ))}
    </div>
  );
}

// Individual Post Page
function PostPage() {
  const { id } = useParams();
  const post = posts.find((p) => p.id === parseInt(id));

  if (!post) {
    return (
      <div>
        <p>Post not found!</p>
        <Link to="/">← Back to Home</Link>
      </div>
    );
  }

  return (
    <div>
      <Link to="/">← Back to Home</Link>
      <h2>{post.title}</h2>
      <p style={{ color: "#888" }}>{post.date}</p>
      <p>{post.content}</p>
    </div>
  );
}

// Main App with Router
export default function App() {
  return (
    <BrowserRouter>
      <nav style={{ background: "#f0f0f0", padding: "10px" }}>
        <Link to="/">Home</Link>
      </nav>

      <div style={{ padding: "20px" }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/post/:id" element={<PostPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
