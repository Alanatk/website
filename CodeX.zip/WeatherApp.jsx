import React, { useState } from "react";

export default function App() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);

  const getWeather = () => {
    if (city.trim() === "") return;

    setLoading(true);
    setWeather(null);

    // Simulated API fetch with delay
    setTimeout(() => {
      const fakeWeatherData = {
        city: city,
        temperature: "30°C",
        condition: "Sunny",
        humidity: "60%",
        wind: "12 km/h",
      };

      setWeather(fakeWeatherData);
      setLoading(false);
    }, 2000);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px", fontFamily: "Arial" }}>
      <h1>Weather App</h1>

      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        style={{ padding: "10px", width: "200px" }}
      />

      <button
        onClick={getWeather}
        style={{
          padding: "10px 15px",
          marginLeft: "10px",
          cursor: "pointer",
        }}
      >
        Get Weather
      </button>

      {loading && <p>Loading weather data...</p>}

      {weather && (
        <div
          style={{
            marginTop: "20px",
            border: "1px solid #ccc",
            display: "inline-block",
            padding: "20px",
            borderRadius: "10px",
          }}
        >
          <h2>{weather.city}</h2>
          <p><strong>Temperature:</strong> {weather.temperature}</p>
          <p><strong>Condition:</strong> {weather.condition}</p>
          <p><strong>Humidity:</strong> {weather.humidity}</p>
          <p><strong>Wind Speed:</strong> {weather.wind}</p>
        </div>
      )}
    </div>
  );
}