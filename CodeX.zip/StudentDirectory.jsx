import React, { useEffect, useState } from "react";

export default function App() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStudent, setSelectedStudent] = useState(null);

  useEffect(() => {
    // Simulate data fetching with delay
    setTimeout(() => {
      setStudents([
        { id: 1, name: "Alan", course: "BCA", age: 20, email: "alan@gmail.com" },
        { id: 2, name: "Meera", course: "BBA", age: 21, email: "meera@gmail.com" },
        { id: 3, name: "Rahul", course: "BCom", age: 22, email: "rahul@gmail.com" },
        { id: 4, name: "Anu", course: "MCA", age: 23, email: "anu@gmail.com" }
      ]);
      setLoading(false);
    }, 2000);
  }, []);

  if (loading) {
    return <h2 style={{ textAlign: "center" }}>Loading students...</h2>;
  }

  if (selectedStudent) {
    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <h1>Student Profile</h1>
        <h2>{selectedStudent.name}</h2>
        <p><b>Course:</b> {selectedStudent.course}</p>
        <p><b>Age:</b> {selectedStudent.age}</p>
        <p><b>Email:</b> {selectedStudent.email}</p>
        <button onClick={() => setSelectedStudent(null)}>Back to Directory</button>
      </div>
    );
  }

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Student Directory</h1>
      {students.map((student) => (
        <div
          key={student.id}
          style={{
            border: "1px solid gray",
            padding: "10px",
            margin: "10px auto",
            width: "250px",
            borderRadius: "8px"
          }}
        >
          <h3>{student.name}</h3>
          <p>{student.course}</p>
          <button onClick={() => setSelectedStudent(student)}>
            View Profile
          </button>
        </div>
      ))}
    </div>
  );
}