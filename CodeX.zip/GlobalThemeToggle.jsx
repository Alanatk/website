import React, { useState } from "react";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const appStyle = {
    backgroundColor: darkMode ? "#222" : "#f5f5f5",
    color: darkMode ? "#fff" : "#000",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    transition: "0.3s",
  };

  const boxStyle = {
    backgroundColor: darkMode ? "#333" : "#fff",
    padding: "30px",
    borderRadius: "10px",
    boxShadow: "0 0 10px rgba(0,0,0,0.2)",
    textAlign: "center",
  };

  const buttonStyle = {
    marginTop: "20px",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    backgroundColor: darkMode ? "#fff" : "#222",
    color: darkMode ? "#000" : "#fff",
  };

  return (
    <div style={appStyle}>
      <div style={boxStyle}>
        <h1>{darkMode ? "Dark Mode" : "Light Mode"}</h1>
        <p>The entire site theme changes globally.</p>
        <button style={buttonStyle} onClick={() => setDarkMode(!darkMode)}>
          Toggle Theme
        </button>
      </div>
    </div>
  );
}

export default App;