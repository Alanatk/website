import React, { useState } from "react";

function App() {
  const posts = [
    {
      id: 1,
      title: "Introduction to React",
      content:
        "React is a JavaScript library used to build user interfaces with reusable components."
    },
    {
      id: 2,
      title: "Why Use Components?",
      content:
        "Components help split the UI into independent, reusable pieces that make code easier to manage."
    },
    {
      id: 3,
      title: "Understanding State",
      content:
        "State allows React components to store and update dynamic data, making apps interactive."
    }
  ];

  const [selectedPost, setSelectedPost] = useState(null);

  return (
    <div style={{ fontFamily: "Arial", padding: "20px" }}>
      <h1>My Blog Site</h1>

      {!selectedPost ? (
        <div>
          <h2>Home Page</h2>
          <p>Welcome to the blog! Click a post to read more.</p>

          {posts.map((post) => (
            <div
              key={post.id}
              style={{
                border: "1px solid #ccc",
                padding: "10px",
                margin: "10px 0",
                borderRadius: "5px"
              }}
            >
              <h3>{post.title}</h3>
              <button onClick={() => setSelectedPost(post)}>Read More</button>
            </div>
          ))}
        </div>
      ) : (
        <div>
          <button onClick={() => setSelectedPost(null)}>← Back to Home</button>
          <h2>{selectedPost.title}</h2>
          <p>{selectedPost.content}</p>
        </div>
      )}
    </div>
  );
}

export default App;