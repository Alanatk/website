import { Navigate } from "react-router-dom";

function Admin({user}){
  if(user!=="admin"){
    return <Navigate to="/" />
  }

  return <h2>Admin Panel</h2>
}

export default Admin;