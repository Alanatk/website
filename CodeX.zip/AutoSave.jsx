import { useState, useEffect } from "react";

export default function App(){
  const [text,setText]=useState(localStorage.getItem("draft") || "");

  useEffect(()=>{
    const interval=setInterval(()=>{
      localStorage.setItem("draft",text);
    },3000);

    return()=>clearInterval(interval);
  },[text]);

  return(
    <textarea
      value={text}
      onChange={(e)=>setText(e.target.value)}
    />
  )
}