import React, { useState } from "react";

function App() {
  const [feedback, setFeedback] = useState("");
  const [responses, setResponses] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (feedback.trim() === "") return;

    setResponses([...responses, feedback]);
    setFeedback("");
  };

  return (
    <div style={styles.container}>
      <h1>Feedback Collector App</h1>

      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          placeholder="Enter your feedback"
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          style={styles.input}
        />
        <button type="submit" style={styles.button}>
          Submit
        </button>
      </form>

      <h2>All Responses</h2>
      <ul style={styles.list}>
        {responses.map((item, index) => (
          <li key={index} style={styles.listItem}>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

const styles = {
  container: {
    textAlign: "center",
    marginTop: "50px",
    fontFamily: "Arial",
  },
  form: {
    marginBottom: "20px",
  },
  input: {
    padding: "10px",
    width: "250px",
    marginRight: "10px",
  },
  button: {
    padding: "10px 20px",
    cursor: "pointer",
  },
  list: {
    listStyleType: "none",
    padding: 0,
  },
  listItem: {
    background: "#f2f2f2",
    margin: "8px auto",
    padding: "10px",
    width: "300px",
    borderRadius: "5px",
  },
};

export default App;